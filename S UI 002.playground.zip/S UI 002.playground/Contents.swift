import UIKit

let betaNumber:String = "B"

var mainNumber: String

var temperatuer: Double

var Numbers: Array<String> = [String]()

var alfaNumbers = [String: Int]()

var Seth = Set<String>()

enum eharactersEnum {
    case A, E, C, B
}

// Challenge

var mesa: Array<String> = ["MacBook Air", "Universal Audio", "Genelec"]
print("The table has \(mesa)")
print("Number of itens on table: \(mesa.count)")

