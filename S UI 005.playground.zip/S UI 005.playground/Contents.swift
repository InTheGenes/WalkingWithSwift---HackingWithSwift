import UIKit

func hello() {
    print("hello")
}

hello()

var helloCopy = hello

helloCopy()

let sayHello = { (name: String) -> String in
    "Hi \(name)!"
}

let Numeros = { (number: Int) -> String in "Hi \(number)" }
Numeros(1)

func getUserData(for id: Int) -> String {
    if id == 1989 {
        return "Taylor Swift"
    } else {
        return "Anonymous"
    }
}

let data: (Int) -> String = getUserData
let user = data(1989)
print(user)

func numeroRNome(Num: Int) -> String {
    if Num == 1 {
        return "Lucas"
    }
    return "X"
}

print(numeroRNome(Num: 1))

let NRetorna: (Int) -> String = numeroRNome
let userX = NRetorna(1)
print(userX)


let team = ["Gloria", "Suzanne", "Piper", "Tiffany", "Tasha"]
let sortedTeam = team.sorted()
print(sortedTeam)

func captainFirstSorted(name1: String, name2: String) -> Bool {
    if name1 == "Suzanne" {
        return true
    } else if name2 == "Suzanne" {
        return false
    }

    return name1 < name2
}

let captainFirstTeam = team.sorted(by: captainFirstSorted)
print(captainFirstTeam)

let ArraySpy = ["A1", "B2", "C3", "Z4", "X5"]
let ArraySpyInOrder = ArraySpy.sorted()
print(ArraySpyInOrder)

func ArrayCapitain(SpyCapitain: String, SpyMembers: String) -> Bool {
    if SpyCapitain == "C3" {
        return true
    } else if SpyMembers == "C3" {
        return false
    }
    return SpyCapitain < SpyMembers
}

let CapFirst = ArraySpy.sorted(by: ArrayCapitain)
print(CapFirst)

// Oh my gosh.
let captainFirstTeamX = team.sorted(by: { (name1: String, name2: String) -> Bool in
    if name1 == "Suzanne" {
        return true
    } else if name2 == "Suzanne" {
        return false
    }

    return name1 < name2
})

print(captainFirstTeamX)

//Oh my gosh.
func makeArray(size: Int, using generator: () -> Int) -> [Int] {
    var numbers = [Int]()

    for _ in 0..<size {
        let newNumber = generator()
        numbers.append(newNumber)
    }

    return numbers
}

let rolls = makeArray(size: 50) {
    Int.random(in: 1...20)
}

print(rolls)

func doImportantWork(first: () -> Void, second: () -> Void, third: () -> Void) {
    print("About to start first work")
    first()
    print("About to start second work")
    second()
    print("About to start third work")
    third()
    print("Done!")
}

doImportantWork {
    print("This is the first work")
} second: {
    print("This is the second work")
} third: {
    print("This is the third work")
}
