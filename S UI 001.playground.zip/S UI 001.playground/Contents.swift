import UIKit

var temperature: Double = 3.0
let fullTemperatureCelsius: String = " \(temperature) °C"
print(fullTemperatureCelsius)

let Convert2Fahrenhit = temperature * 9 / 5 + 32
print("\(Convert2Fahrenhit) °F")
