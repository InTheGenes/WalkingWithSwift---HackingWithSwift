import UIKit


printLoopVezesNúmero(numero: 9, até: 9)
// "numero" e "até" são parâmetros.
// argumentos são os valores reais passados. Ex 5; 9; "Me"
// printLoop[...]  = That’s known as the function’s call site, which is a fancy name meaning “a place where a function is called.”
// argumentos são destruidos depois que a função for chamada.

// Next

let root = sqrt(169)
print(root)

func rollDice() -> Int {
    return Int.random(in: 1...6)
}
let result = rollDice()
print(result)

func areLettersIdentical(string1: String, string2: String) -> Bool {
    string1.sorted() == string2.sorted()
}
let X = areLettersIdentical(string1: "a", string2: "a")
print(X)

func pythagoras(a: Double, b: Double) -> Double {
    sqrt((a * a) + (b * b))
}
let c = pythagoras(a: 10, b: 24)
print(c)


func isUppercase(string: String) -> Bool {
    string == string.uppercased()
}

func getUserArray() -> [String] {
    ["Me", "You"]
}
let userArray = getUserArray()
print("Names: \(userArray[0]), \(userArray[1])")

func getUserDict() -> [String:String] {
    ["Me": "Lucas", "You": "N, the s2"]
}
let userDict = getUserDict()
print("Name: \(userDict["Me", default: "Anonymous"]) iLw \(userDict["You", default: "Anonymous"])")

//

func getUserTup() -> (firstName: String, lastName: String) {
    (firstName: "Taylor", lastName: "Swift")
}
let userTup = getUserTup()
print("Name: \(userTup.firstName) \(userTup.lastName)")

func getUserTup2() -> (firstName: String, lastName: String) {
    ("Taylor", "Swift")
}
let userTup2 = getUserTup2()
print("Name: \(userTup2.0) \(userTup2.1)")

func tuplamaluca() -> (Loco: String, Maluco: String) {
    ("Ningúem", "Nobody")
}
let userTM = tuplamaluca()
print("\(userTM.Loco), \(userTM.Maluco)")

func tuplamaluca2() -> (String, String) {
    ("Ningúem", "Nobody")
}
let userTM2 = tuplamaluca2()
print("\(userTM2.0), \(userTM2.1)")



//
func getUser33() -> (firstName: String, lastName: String) {
    (firstName: "Taylor", lastName: "Swift")
}
let user33 = getUser33()
let firstName = user33.firstName
let lastName = user33.lastName
print("Name: \(firstName) \(lastName)")
//


func getUser13() -> (firstName2: String, lastName2: String) {
    (firstName2: "Taylor", lastName2: "Swift")
}
let (firstName2, lastName2) = getUser13()
print("Name: \(firstName2) \(lastName2)")

//


func rollDice(sides: Int, count: Int) -> [Int] {
    // Start with an empty array
    var rolls = [Int]()
    // Roll as many dice as needed
    for _ in 1...count { //"_" = ignorar parâmetro.
        // Add each result to our array
        let roll = Int.random(in: 1...sides)
        rolls.append(roll)
    }
    // Send back all the rolls
    return rolls
}
let rolls = rollDice(sides: 6, count: 3)
print("\(rolls)")



func isUppercase(_ string: String) -> Bool { //ignorar parâmetro
    string == string.uppercased()
}
let string = "HELLO, WORLD"
let result2 = isUppercase(string)



// * Por que usar o "i"? Que diferença faria em um código mais complexo, se é que existe?
func printTimesTables(for number: Int) {
    for i in 1...12 {
        print("\(i) x \(number) is \(i * number)")
    }
}
printTimesTables(for: 5)


func printLoopVezesNúmero(numero: Int, até: Int) {
    for loop in 1...até {
        print("\(loop) x \(numero) = \(loop * numero)")
    }
}

func tabela(deQualNumero: Int, atéQualNúmero: Int) {
    for contagemX in 1...atéQualNúmero {
        print("\(contagemX) x \(deQualNumero) = \(contagemX * deQualNumero)")
    }
}
tabela(deQualNumero: 5, atéQualNúmero: 5)

var characters = ["Lana", "Pam", "Ray", "Sterling"]
print(characters.count)
characters.removeAll(keepingCapacity: true)
print(characters.count)

// keepingCapacity = mantém o número de itens dentro da Array.

//

enum PasswordError: Error {
    case short, obvious
}

func checkPassword(_ password: String) throws -> String {
    if password.count < 5 {
        throw PasswordError.short
    }
    if password == "12345" {
        throw PasswordError.obvious
    }
    if password.count < 8 {
        return "OK"
    } else if password.count < 10 {
        return "Good"
    } else {
        return "Excellent"
    }
}

let senhaMaluca = "12345"

do {
    let result = try checkPassword(senhaMaluca)
    print("Password rating: \(result)")
} catch {
    print("There was an error.")
}



func checarSenha(senhaX: String) throws -> String {
    if senhaX == "Abcde" {
        throw PasswordError.obvious
    }
    if senhaX.count < 5 {
        throw PasswordError.short
    }
    
    if senhaX.count < 8 {
        return "OK"
    }
    else if senhaX.count < 10 {
        return "OK2"
    } else {
        return "good"
    }
}

do {
    let resultado = try checarSenha(senhaX: senhaMaluca)
    print("score pass \(resultado)")
} catch {
    print("ops")
}
