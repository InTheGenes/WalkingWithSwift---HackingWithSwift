import UIKit

var alfaIsReal = true

if alfaIsReal {
    print{"A = 1"}
}

var numbersX: Array<Int> = [1,11,111,1111]
if numbersX.count > 3 {
    numbersX.remove(at: 0)
}
print(numbersX)

if numbersX.count != 4 {
    print("Not yet.")
}
if numbersX.count == 3 {
    print("Maybe it's [ \(3 * 6) / 9 ] + 1")
}


var textField: String = ""
if textField.isEmpty {
    print("Only light creator speak with no words.")
} else if textField.count == 0 {
    print("Only light creator speak with no words.")
} else if textField.hasPrefix("") {
    print("Only light creator speak with no words.")
} else {
    print("Omg, i don't have telephatic powers!")
}

var beyondDuality = 7

if beyondDuality == 2 {
    print("You need something else.")
} else if beyondDuality >= 3 {
    print("More than 1ndividuality and more than duality(2)")
} else {
    print("Can you give a false exemple?")
}

if beyondDuality >= 3 && beyondDuality <= 9 {
    print("Your mind has blowing. Saturn was superated.")
} else {
    print("Keep trying, we don't stop to evolving. You are the evolution.")
}

var ageIStarted = 13
var doYouLoveAndDontMind = true

if ageIStarted >= 18 || doYouLoveAndDontMind == true {
    print("Go ahead, freedom is the key.")
} else {
    print("Connect with Freedom Fighters")
}

enum sensitivityHeaven {
    case Sight, Hearing, Touch, Smell, Taste
}
var sensitivity = sensitivityHeaven.Hearing

if sensitivity == .Sight || sensitivity == .Hearing {
    print("Já pensou em pintura OU em música?")
} else if sensitivity == .Touch {
    print("Reiki?")
} else {
    print("Let's cook?")
}

// Switch statement
// A switch statement considers a value and compares it against several possible matching patterns.
var omegaNumbers = 2
switch omegaNumbers {
case 1:
    print("A")
    fallthrough
case 2:
    print("B")
    fallthrough
case 3:
    print("C")
    fallthrough
default: print("Out of range.")
}

omegaNumbers = 3
// How print C?

let minAge = 18
let canVote = minAge >= 18 ? "Yes" : "No"
// "[...]age >= 18[...]" is a condition.

// ternary operator
let hour = 11
print(hour >= 12 ? "This is second half." : "This is the first half.")

// ternary operator
let NumbersZ = [3,6,9]
let CheckingNumbersZ = NumbersZ.isEmpty ? "Empty Array" : "Array got \(NumbersZ.count) numbers."
print(CheckingNumbersZ)

// ternary operator
enum BlacknWhite {
    case black, white
}
var force = BlacknWhite.black
var side = force == .black ? "Good force. I love." : "I love. Good force"
print(side)

//Loops *for

let platforms = ["iOS", "macOS", "tvOS", "watchOS"]
for os/*loop variable*/ in platforms {
    print("Call me: \(os)") //"loop body" loop itaration
}

for platform in platforms {
    print("i'm \(platform)")
}

for i in 1...3 {
    print("The \(i) times tabble")
    for j in 1..<4 {
        print("\(j) x \(i) is \(j * i)")
    }
    print() // this add a empty line.
}

var lyric = "lovers gonna"
for _ in 1...9 {
    lyric += " love" //+= adiciona, range determina a qntidade q a string é add. adição final da string.
}
print(lyric)

//While loop
var contagem = Int.random(in: 5...9)
while contagem > 3 {
    print("\(contagem)")
    contagem -= 1
}

//Best ex ever.
var rolar = 0
while rolar != 20 {
    rolar = Int.random(in: 1...20)
    print("Rolou no número \(rolar)")
}

let filenames = ["me.jpg", "work.txt", "sophie.jpg", "logo.psd"]
for filename in filenames {
    if filename.hasSuffix(".jpg") == false {
        continue
    }
    print("Found picture: \(filename)")
} // Quando *continuo*, significa, sobre o que o que for falso em ter o sulf .jpg, que decidimos seguir para oos outros itens da coleção, e, portanto, sem executar o código contido no for. Obs: o if está dentro do for.

let number1 = 3
let number2 = 6
let number3 = 9

var multiples = [Int]()

for i in 1...100_0 {
    if i.isMultiple(of: number1) && i.isMultiple(of: number2) && i.isMultiple(of: number3) {
        multiples.append(i)

        if multiples.count == 10 {
            break // para a operação inteira.
        }
    }
}

print(multiples)
