import UIKit
import Foundation

var greeting = "Hello, playground"

enum PasswordError: Error {
    case higherLower, noMatch
}

func root(of zahl: Int) throws -> String {
    guard zahl > 1 && zahl < 10000 else {
        throw PasswordError.higherLower
    }

    for i in 1...100 {
        if zahl == i * i {
            return "\(i)"
        }
    }

    throw PasswordError.noMatch
}

do {
    let result = try root(of: 81)
    print("The root is \(result)")
} catch PasswordError.higherLower {
    print("Out of bounds")
} catch PasswordError.noMatch {
    print("No Root")
} catch {
    print("Help")
}

func RaizQuadrada(of number: Int) throws -> String {
    guard number > 1 && number < 10000 else {
        throw PasswordError.higherLower
    }
    
    for i in 1...100 {
        if number == i * i {
            return "\(i)"
        }
    }
    throw PasswordError.noMatch
}

do {
    let result = try root(of: 81)
    print("\(result)")
          } catch PasswordError.higherLower {
        print("tá fora.")
          } catch PasswordError.noMatch {
              print("tá fora, no INT")
          } catch {
              print("help")
}






















func RaizQ(of number: Int) throws -> String {
    guard number > 1 && number < 10000 else {
        throw PasswordError.higherLower
    }
    for i in 1...100 {
        if number == i * i {
            return ("\(i)")
        }
    }
    throw PasswordError.noMatch
}

do {
    let result = try root(of: 900)
    print("\(result)")
} catch PasswordError.higherLower {
    print("H n L")
} catch PasswordError.noMatch {
    print("Não é inteiro")
} catch {
    print("help")
}

















func RQ(númb: Int) throws -> String {
    guard númb > 1 && númb < 1000 else {
        throw PasswordError.higherLower
    }
    
    for i in 1...100 {
        if númb == i * i {
            print("\(i)")
        }
    }
    throw PasswordError.noMatch
}

do {
    let Rst = try root(of: 9)
    print("\(Rst)")
} catch PasswordError.higherLower {
    print("H n L.")
          } catch PasswordError.noMatch {
    print("No match.")
    }  catch {
        print("Help.")
    }































