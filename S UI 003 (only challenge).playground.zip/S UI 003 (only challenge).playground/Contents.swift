import UIKit

let multiploDe3 = "Fizz"
let multiploDe5 = "Buzz"
let multiploDe3e5 = "FizzBuzz"

for number in 1...100 {
    if number.isMultiple(of: 3) && number.isMultiple(of: 5) {
         print(multiploDe3e5)
    }
    else if number.isMultiple(of: 3) {
        print(multiploDe3)
    }
    else if number.isMultiple(of: 5) {
        print(multiploDe5)
    }
    else {
        print(number)
    }
}
